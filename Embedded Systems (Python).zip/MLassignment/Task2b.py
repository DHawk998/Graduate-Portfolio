import time
from Task1b import Sharedfifobuffer
from Task2a import Dataloader, Preprocessor, Modeltrainer, Evaluator


class Bufferedpipeline: #The pipeline to connect stages through a shared buffer without direct calling.
    def __init__(self, file_path, capacity=2, test_size=0.2, rng=50, trees=100): #Four stages of the sequential pipeline.
        self.loader = Dataloader(file_path, test_size, rng)
        self.preprocessor = Preprocessor()
        self.trainer = Modeltrainer(trees, rng)
        self.evaluator = Evaluator()
        self.loader_buffer = Sharedfifobuffer(capacity) #buffers connecting each stage together.
        self.preprocessor_buffer = Sharedfifobuffer(capacity)
        self.trainer_buffer = Sharedfifobuffer(capacity)
        self.eval_buffer = Sharedfifobuffer(capacity)

    def run(self, verbose=True):
        t0 = time.perf_counter() #start timer.

        self.loader_buffer.addtoqueue(self.loader.load()) #loads and splits data, add to first buffer.

        X_train, X_test, y_train, y_test = self.loader_buffer.dequeue() #take raw data and scale, add to second buffer.
        self.preprocessor_buffer.addtoqueue((*self.preprocessor.fit_transform(X_train, X_test), y_train, y_test))

        X_train_s, X_test_s, y_train, y_test = self.preprocessor_buffer.dequeue() #scale data and train model, add to third buffer.
        self.trainer_buffer.addtoqueue((self.trainer.train(X_train_s, y_train), X_test_s, y_test))

        model, X_test_s, y_test = self.trainer_buffer.dequeue() #test and evaluate data, add to last buffer.
        self.eval_buffer.addtoqueue(self.evaluator.evaluate(model, X_test_s, y_test))

        results = self.eval_buffer.dequeue() #obtain results from last buffer.
        elapsed = time.perf_counter() - t0 #stop timer.

        if verbose:
            print(f"RMSE: {results['rmse']:.2f}°C")
            print(f"R² Score: {results['r2']:.4f}")
            print(f"Duration: {elapsed*1000:.2f} ms")

        return results, elapsed


if __name__ == "__main__":
    FILE_PATH = "C:/Users/mail2/OneDrive/Documents/UNI_assignments/Python_Exercises/MLassignment/weather.csv"
    
    p = Bufferedpipeline(FILE_PATH)
    results, _ = p.run()
    
    print("\nPassed")