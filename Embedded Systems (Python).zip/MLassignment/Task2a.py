import time
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score


class Dataloader: #Loads weather data from excel file to training and testing sets.
    def __init__(self, file_path, test_size=0.2, rng=50):
        self.file_path = file_path #file path of data.
        self.test_size = test_size #the size of data reserved for testing.
        self.rng = rng #Training and testing split stays the same, rng = random number generator.
        self._data = None
    def load(self): #load data
      
        self._data = pd.read_csv(self.file_path)
        X = self._data.drop(['date', 'max_temp'], axis=1).values  #Input features.
        y = self._data['max_temp'].values  #target variable for predictions.
        
        # Remove any rows with missing values
        mask = ~(np.isnan(X).any(axis=1) | np.isnan(y))
        X = X[mask]
        y = y[mask]
        
        return train_test_split(X, y, test_size=self.test_size, #return the testing/training split.
                                random_state=self.rng)

class Preprocessor: #scales all features to have mean 0 deviation 1.
    def __init__(self):
        self.scaler = StandardScaler()

    def fit_transform(self, X_train, X_test): #transforms both sets to avoid data leakage.
        return self.scaler.fit_transform(X_train), self.scaler.transform(X_test) #scales on training data only.


class Modeltrainer: #trains random forest to predict temperature
    def __init__(self, trees=100, rng=50):
        self.model = RandomForestRegressor(n_estimators=trees,
                                           random_state=rng)

    def train(self, X_train, y_train): #train on scaled data.
        self.model.fit(X_train, y_train)
        return self.model


class Evaluator: #evaluate regression model performance.
    def evaluate(self, model, X_test, y_test):
        y_pred = model.predict(X_test) #get predictions on the unseen data.
        return {
            "rmse": np.sqrt(mean_squared_error(y_test, y_pred)),
            "r2": r2_score(y_test, y_pred),
            "predictions": y_pred,
            "actual": y_test
        }


class SequentialPipeline: #pipeline for all four stages.
    def __init__(self, file_path, test_size=0.2, rng=50, trees=100):
        self.loader = Dataloader(file_path, test_size, rng)
        self.preprocessor = Preprocessor()
        self.trainer = Modeltrainer(trees, rng)
        self.evaluator = Evaluator()

    def run(self, verbose=True):
        t0 = time.perf_counter() #starts timer.
        
        #Loads and split data.
        X_train, X_test, y_train, y_test = self.loader.load()
        
        #Scale the input features.
        X_train_s, X_test_s = self.preprocessor.fit_transform(X_train, X_test)
        
        #Train model.
        model = self.trainer.train(X_train_s, y_train)
        
        #Evaluate the data.
        results = self.evaluator.evaluate(model, X_test_s, y_test)
        
        elapsed = time.perf_counter() - t0
        
        if verbose:
            print(f"RMSE: {results['rmse']:.2f}°C")
            print(f"R²: {results['r2']:.4f}")
            print(f"Duration: {elapsed*1000:.2f} ms")
        
        return results, elapsed


if __name__ == "__main__":
    FILE_PATH = "C:/Users/mail2/OneDrive/Documents/UNI_assignments/Python_Exercises/MLassignment/weather.csv"
    
    print("Weather Temperature Prediction ")
    p = SequentialPipeline(FILE_PATH)
    results, _ = p.run()
    
    # Show sample predictions vs actual.
    print("\nSample predictions (first 10 test samples):")
    print("Actual - Predicted")
    for i in range(min(10, len(results['actual']))):
        print(f"{results['actual'][i]:.1f}°C  -  {results['predictions'][i]:.1f}°C")
    
    print("\nPassed")