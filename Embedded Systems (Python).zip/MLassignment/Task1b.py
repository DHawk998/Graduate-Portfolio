import threading

DONE = object()

class Sharedfifobuffer:
    def __init__(self, capacity: int):
        if capacity <= 0:
            raise ValueError(f"capacity must be > 0, got {capacity!r}")
        self.capacity = capacity
        self._buffer = [None] * capacity
        self.front = 0
        self.back = 0
        self.size = 0
        self.lock = threading.Lock() #mutex and condition variables for thread safety.
        self.can_write = threading.Condition(self.lock) #producer waits.
        self.can_read = threading.Condition(self.lock) #consumer waits.

    def addtoqueue(self, item, block=True, timeout=None): #adds item to the back of the queue. Block controls if we wait or return immediately when addtoqueue is full.
        with self.can_write:
            if not block and self.size == self.capacity:
                return False #if fifo full and block = false.
            while self.size == self.capacity:
                if timeout is not None:
                    import time
                    if not self.can_write.wait(timeout): 
                        return False #if timer runs out return false.
                else:
                    self.can_write.wait() #wait until not full.
            self._buffer[self.back] = item
            self.back = (self.back + 1) % self.capacity #loop back when full.
            self.size += 1
            self.can_read.notify() #consumer notified buffer has an item
            return True

    def dequeue(self, block=True, timeout=None): #removes and returns first item in queue.
        with self.can_read:
            if not block and self.size == 0:
                return None
            while self.size == 0:
                if timeout is not None:
                    import time
                    if not self.can_read.wait(timeout):
                        return None #if timer runs out return false.
                else:
                    self.can_read.wait() #wait until buffers isn't empty.
            value = self._buffer[self.front]
            self._buffer[self.front] = None
            self.front = (self.front + 1) % self.capacity #loops to start when full.
            self.size -= 1
            self.can_write.notify() #notfies producer there is space.
            return value

    def done(self): #adds end signal to queue.
        self.addtoqueue(DONE)

if __name__ == "__main__": #self test.
    import time

    buf = Sharedfifobuffer(5) #buffer created with a capacity of 5.
    results = [] #stores items collected by consumer.

    def producer():
        for i in range(6):
            buf.addtoqueue(i) #items added to buffer.
            time.sleep(0.05) #delay so consumer can process in time.
        buf.done() #ends buffer

    def consumer():
        while True:
            v = buf.dequeue() #waits for buffer to be empty.
            if v is DONE: #check if buffer ended .
                break
            results.append(v) #collect items.
            time.sleep(0.1) #delay for producer to catch up.

    t1 = threading.Thread(target=producer) #run both threads at the same time.
    t2 = threading.Thread(target=consumer)
    t1.start(); t2.start()
    t1.join(); t2.join() #wait for btoh to finish.

    assert results == [0, 1, 2, 3, 4, 5] #checks to see all expected outcomes and verifies.
    print("Passed:", results)

    b = Sharedfifobuffer(2) #testing non-blocking behaviour with a small buffer.
    assert b.addtoqueue("x", block=False) #space available
    assert b.addtoqueue("y", block=False) 
    assert not b.addtoqueue("z", block=False) #fails as buffer is full.
    assert b.dequeue(block=False) == "x" #removes first item.
    assert b.dequeue(block=False) == "y" #removes second item.
    assert b.dequeue(block=False) is None #empty buffer.
    print("Non-blocking passed")