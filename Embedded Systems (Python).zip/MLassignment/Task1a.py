class FifoBuffer:
    def __init__(self, capacity: int):
        if capacity <= 0:
            raise ValueError(f"capacity must be > 0") #must have a capacity of at least 1.
        self.capacity = capacity
        self.buffer = [None] * capacity
        self.front = 0 #front of fifo.
        self.back = 0 #back of fifo.
        self.size = 0

    def addtoqueue(self, item) -> bool: #adds item to the back of the queue, if full than should return false.
        if self.size == self.capacity:
            return False
        self.buffer[self.back] = item
        self.back = (self.back + 1) % self.capacity #loops back to start when full.
        self.size += 1
        return True

    def dequeue(self): #removes and returns first item, if no items then will return nothing.
        if self.size == 0:
            return None
        value = self.buffer[self.front]
        self.buffer[self.front] = None
        self.front = (self.front + 1) % self.capacity #Loops back to start when reaching the end.
        self.size -= 1
        return value
    
if __name__ == "__main__": #self test.
    buff= FifoBuffer(3) #buffer is created with capacity of three.
    buff.addtoqueue(1); buff.addtoqueue(2); buff.addtoqueue(3) #add the three items to queue.
    print(buff.addtoqueue(4))   #no capacity for 4th item so should be false.
    print(buff.dequeue())    # 1.
    print(buff.dequeue())    # 2.
    print(buff.dequeue())    # 3.
    print(buff.dequeue())    # None (empty).
