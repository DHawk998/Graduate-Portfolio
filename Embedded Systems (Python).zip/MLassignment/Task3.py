import threading
import time
import numpy as np
from Task1b import Sharedfifobuffer, DONE
from Task2a import Dataloader, Preprocessor, Modeltrainer, Evaluator

class PoolACM: #4-slot pool ACM.
    def __init__(self):
        self.slots = [None, None, None, None]  # 4 data slots to avoid write/read clashes.
        self.w = 0   #writer's current slot.
        self.r = 0   #reader's current slot.
        self.l = 0   # last slot written to.
        self.s = [0, 0, 0, 0]  # status indicator switches to 1 when new data arrives and back to 0 when read.

    def write(self, item): #writer stores item without blocking, picks slot reader not using.
        slot = self.w
        if slot == self.r:  #avoids clashing with reader.
            slot = (self.w + 1) % 4 #finds the next avialable slot.
        
        self.slots[slot] = item            #store data in chosen slot.
        self.s[slot] = 1 - self.s[slot]    #update status for new data.
        self.l = slot                       
        self.w = (slot + 1) % 4             #Write at next slot.

    def read(self): #reader gets latest data without blocking
        # if status changed, new data exists.
        if self.s[self.l] != self.s[self.r]:
            self.r = self.l  #move reader to latest written slot.
        
        return self.slots[self.r]  #read whatever is in current slot.
    
class ACM_implementation: #Pool ACM replacing buffer between loader and preprocessor. Loading should now be able to have continuous rewriting and rereading. 
    def __init__(self, file_path, capacity=4, test_size=0.2, rng=50, trees=100):
        self.loader = Dataloader(file_path, test_size, rng)
        self.preprocessor = Preprocessor()
        self.trainer = Modeltrainer(trees, rng)
        self.evaluator = Evaluator()
        self.loader_buffer = PoolACM()     # Pool ACM replaces the first FIFO buffer
        self.preprocessor_buffer = Sharedfifobuffer(capacity)
        self.trainer_buffer = Sharedfifobuffer(capacity)
        self.eval_buffer = Sharedfifobuffer(capacity)
        self.ready = threading.Event()  #signals for when loader has written.

    def Loader(self): #Thread 1 loads data into pool ACM.
        self.loader_buffer.write(self.loader.load())
        self.ready.set()  #notifies preprocessor that there is data available.

    def preprocess(self): #Thread 2 scales features. Reads from the pool.
        self.ready.wait()  #waits until loader has written something.
        item = self.loader_buffer.read()
        X_train, X_test, y_train, y_test = item
        self.preprocessor_buffer.addtoqueue((*self.preprocessor.fit_transform(X_train, X_test), y_train, y_test))
        self.preprocessor_buffer.done() #tells training that preprocessing is done.

    def training(self): #Thread 3 trains the model.
        item = self.preprocessor_buffer.dequeue() #wait for processed data.
        if item is DONE: return
        X_train_s, X_test_s, y_train, y_test = item
        self.trainer_buffer.addtoqueue((self.trainer.train(X_train_s, y_train), X_test_s, y_test))
        self.trainer_buffer.done() #notifies next stage that processing is complete.

    def evaluate(self): #Thread 4 tests the model and saves results.
        item = self.trainer_buffer.dequeue() #wait for training model.
        if item is DONE: return #Stop at the done signal.
        model, X_test_s, y_test = item
        self.eval_buffer.addtoqueue(self.evaluator.evaluate(model, X_test_s, y_test))
        self.eval_buffer.done()

    def run(self, verbose=True): #Runs all threads to collect final result.
        t0 = time.perf_counter()
        threads = [ #threads are all created
            threading.Thread(target=self.Loader, daemon=True),
            threading.Thread(target=self.preprocess, daemon=True),
            threading.Thread(target=self.training, daemon=True),
            threading.Thread(target=self.evaluate, daemon=True),
        ]
        for t in threads: t.start() #play all the threads.
        for t in threads: t.join() #wait for all threads to finish.

        result = self.eval_buffer.dequeue(block=False) #gets the result and skips the done signal.
        if result is DONE or result is None:
            result = self.eval_buffer.dequeue(block=False)
        elapsed = time.perf_counter() - t0 #stops timer.

        if verbose:
            print(f"RMSE: {result['rmse']:.2f}°C | R²: {result['r2']:.4f} | {elapsed*1000:.2f} ms")

        return result, elapsed

if __name__ == "__main__":
    FILE_PATH = "C:/Users/mail2/OneDrive/Documents/UNI_assignments/Python_Exercises/MLassignment/weather.csv"
    p = ACM_implementation(FILE_PATH)
    r, t = p.run()

    print(f"\nrmse: {r['rmse']:.2f}°C")
    print(f"r2: {r['r2']:.4f}")
    print(f"time: {t*1000:.2f}ms")
   