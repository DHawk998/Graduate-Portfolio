import threading
import time
from Task1b import Sharedfifobuffer, DONE
from Task2a import Dataloader, Preprocessor, Modeltrainer, Evaluator


class Concurrentpipeline:
    def __init__(self, file_path, capacity=4, test_size=0.2, rng=50, trees=100): #runs all four stages concurrently using threads.
        self.loader = Dataloader(file_path, test_size, rng)
        self.preprocessor = Preprocessor()
        self.trainer = Modeltrainer(trees, rng)
        self.evaluator = Evaluator()
        self.loader_buffer = Sharedfifobuffer(capacity)
        self.preprocessor_buffer = Sharedfifobuffer(capacity)
        self.trainer_buffer = Sharedfifobuffer(capacity)
        self.eval_buffer = Sharedfifobuffer(capacity)

    def Loader(self): #Thread 1 loads data and adds to buffer.
        self.loader_buffer.addtoqueue(self.loader.load())
        self.loader_buffer.done()

    def preprocess(self): #Thread 2 scales features.
        item = self.loader_buffer.dequeue() #wait for data from the loader.
        if item is DONE: return
        X_train, X_test, y_train, y_test = item
        self.preprocessor_buffer.addtoqueue((*self.preprocessor.fit_transform(X_train, X_test), y_train, y_test))
        self.preprocessor_buffer.done() #notifies next stage that processing is complete.

    def training(self): #Thread 3 trains the model.
        item = self.preprocessor_buffer.dequeue() #wait for processed data.
        if item is DONE: return
        X_train_s, X_test_s, y_train, y_test = item
        self.trainer_buffer.addtoqueue((self.trainer.train(X_train_s, y_train), X_test_s, y_test))
        self.trainer_buffer.done() #notifies next stage that processing is complete.

    def evaluate(self): #Thread 4 tests the model and saves results.
        item = self.trainer_buffer.dequeue() #wait for training model.
        if item is DONE: return #Stop at the done signal.
        model, X_test_s, y_test = item
        self.eval_buffer.addtoqueue(self.evaluator.evaluate(model, X_test_s, y_test))
        self.eval_buffer.done()

    def run(self, verbose=True): #Runs all threads to collect final result.
        t0 = time.perf_counter()
        threads = [ #threads are all created
            threading.Thread(target=self.Loader, daemon=True),
            threading.Thread(target=self.preprocess, daemon=True),
            threading.Thread(target=self.training, daemon=True),
            threading.Thread(target=self.evaluate, daemon=True),
        ]
        for t in threads: t.start() #play all the threads.
        for t in threads: t.join() #wait for all threads to finish.

        result = self.eval_buffer.dequeue(block=False) #gets the result and skips the done signal.
        if result is DONE or result is None:
            result = self.eval_buffer.dequeue(block=False)
        elapsed = time.perf_counter() - t0 #stops timer.

        if verbose:
            print(f"RMSE: {result['rmse']:.2f}°C | R²: {result['r2']:.4f} | {elapsed*1000:.2f} ms")

        return result, elapsed


if __name__ == "__main__":
    FILE_PATH = "C:/Users/mail2/OneDrive/Documents/UNI_assignments/Python_Exercises/MLassignment/weather.csv"
    p = Concurrentpipeline(FILE_PATH)
    r, _ = p.run()
    print("Passed")